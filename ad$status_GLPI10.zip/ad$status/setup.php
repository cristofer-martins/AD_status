<?php

function plugin_init_adstatus() {
   global $PLUGIN_HOOKS;

   $PLUGIN_HOOKS['csrf_compliant']['adstatus'] = true;

   // Adiciona o CSS
   $PLUGIN_HOOKS['add_css']['adstatus'] = "css/style.css";

   // Registra a classe para aparecer na aba do Usuário
   if (class_exists('PluginAdstatusUserstatus')) {
      Plugin::registerClass('PluginAdstatusUserstatus', array('addtabon' => array('User')));
   }
}

function plugin_version_adstatus() {
   return array(
      'name'           => 'AD Status Realtime',
      'version'        => '1.0.0',
      'author'         => 'Seu Nome',
      'license'        => 'GPLv2+',
      'homepage'       => '',
      'minGlpiVersion' => '10.0' // Ajuste conforme sua versão
   );
}

function plugin_adstatus_check_prerequisites() {
   if (GLPI_VERSION >= 10.0) {
      return true;
   }
   echo "Requer GLPI 10.0 ou superior";
   return false;
}