<?php

if (!defined('GLPI_ROOT')) {
   die("Sorry. You can't access this file directly");
}

class PluginAdstatusUserstatus extends CommonGLPI {

   function getTabNameForItem(CommonGLPI $item, $withtemplate = 0) {
      if ($item->getType() == 'User') {
         return "<i class='fas fa-id-card'></i> Status AD";
      }
      return '';
   }

   static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0) {
      self::showStatusCard($item);
      return true;
   }

   static function showStatusCard($user) {
      // Pega o login do usuário
      $login = $user->fields['name'];

      // Busca configuração do LDAP no GLPI (Pega o primeiro ativo)
      $auth_ldap = new AuthLDAP();
      $ldap_methods = getAllDatasFromTable('glpi_authldaps', ['is_active' => 1]);

      if (empty($ldap_methods)) {
         echo "<div class='alert alert-danger'>Nenhum servidor LDAP configurado no GLPI.</div>";
         return;
      }

      $method = array_shift($ldap_methods);
      
      // Conexão
      $ds = ldap_connect($method['host'], $method['port']);
      ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION, 3);
      ldap_set_option($ds, LDAP_OPT_REFERRALS, 0);

      // Descriptografa senha do rootdn (GLPI 10+)
      $pass = (new GLPIKey())->decrypt($method['rootdn_passwd']);
      $bind = @ldap_bind($ds, $method['rootdn'], $pass);

      if (!$bind) {
         echo "<div class='alert alert-danger'>Erro de bind no AD. Verifique as credenciais no Setup > Autenticação > LDAP.</div>";
         return;
      }

      // Busca
      $filter = "(sAMAccountName=$login)";
      $attributes = ['userAccountControl', 'lockoutTime', 'pwdLastSet', 'lastLogon', 'lastLogonTimestamp'];
      
      $sr = @ldap_search($ds, $method['basedn'], $filter, $attributes);
      $info = ldap_get_entries($ds, $sr);

      if ($info['count'] == 0) {
         echo "<div class='ad-card-container'><div class='ad-status-box unknown'>Usuário não encontrado no AD</div></div>";
         ldap_unbind($ds);
         return;
      }

      // Processamento de Dados
      $uac = $info[0]['useraccountcontrol'][0];
      $lockoutTime = isset($info[0]['lockouttime'][0]) ? $info[0]['lockouttime'][0] : 0;
      $pwdLastSet = isset($info[0]['pwdlastset'][0]) ? $info[0]['pwdlastset'][0] : 0;
      
      // Lógica de Status
      $statusClass = "active";
      $statusText = "ATIVO";
      $icon = "fa-check-circle";
      $reason = "";

      // Bit 2 = Account Disabled
      if ($uac & 2) {
         $statusClass = "disabled";
         $statusText = "DESATIVADO";
         $icon = "fa-ban";
         $reason = "Conta desabilitada manualmente.";
      } 
      // LockoutTime > 0
      elseif ($lockoutTime > 0) {
         $statusClass = "locked";
         $statusText = "BLOQUEADO";
         $icon = "fa-lock";
         $reason = "Excesso de tentativas de senha incorreta.";
      }

      // Cálculo de Datas (Windows Timestamp para Unix)
      $lastLogon = "Nunca";
      if (isset($info[0]['lastlogontimestamp'][0])) {
         $winTime = $info[0]['lastlogontimestamp'][0];
         $unixTime = ($winTime / 10000000) - 11644473600;
         $lastLogon = date("d/m/Y H:i", $unixTime);
      }

      // Renderização HTML
      echo "<div class='ad-card-wrapper'>";
      echo "  <div class='ad-card $statusClass'>";
      echo "    <div class='ad-header'><i class='fas $icon'></i> $statusText</div>";
      
      if ($reason) {
         echo "    <div class='ad-reason'><strong>Motivo:</strong> $reason</div>";
      }

      echo "    <div class='ad-details'>";
      echo "      <div class='ad-detail-item'><strong>Login AD:</strong> $login</div>";
      echo "      <div class='ad-detail-item'><strong>Último Sync:</strong> $lastLogon</div>";
      
      // Senha Expirada? (Cálculo básico se pwdLastSet for 0)
      if ($pwdLastSet == 0) {
          echo "      <div class='ad-detail-item text-danger'><strong>Senha:</strong> Deve alterar no próximo login</div>";
      }

      echo "    </div>"; // details
      echo "  </div>"; // card
      echo "</div>"; // wrapper

      ldap_unbind($ds);
   }
}