<?php

if (!defined('GLPI_ROOT')) {
   die("Sorry. You can't access this file directly");
}

class PluginAdstatusUserstatus extends CommonGLPI {

   function getTabNameForItem(CommonGLPI $item, $withtemplate = 0) {
      if ($item->getType() == 'User') {
         // Verifica se tem permissão se quiser refinar depois
         return "<i class='fas fa-id-card'></i> Status AD";
      }
      return '';
   }

   static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0) {
      // Aqui está a mudança chave para GLPI 10/11:
      // Usamos o Renderizador de Templates
      global $CFG_GLPI;
      
      $data = self::getDataFromAD($item);
      
      // Renderiza o arquivo .html.twig passando o array de dados
      // O '@adstatus' refere-se à pasta do seu plugin
      TemplateRenderer::getInstance()->display('@adstatus/status.html.twig', $data);
      
      return true;
   }

   // Separei a lógica de busca para ficar limpo
   static function getDataFromAD($user) {
      $login = $user->fields['name'];
      
      // Default return (se der erro)
      $default_data = [
          'login' => $login,
          'status_class' => 'unknown',
          'status_text' => 'DESCONHECIDO',
          'icon' => 'fa-question-circle',
          'last_logon' => 'N/A',
          'reason' => '',
          'password_expired' => false,
          'error_msg' => ''
      ];

      $auth_ldap = new AuthLDAP();
      $ldap_methods = getAllDatasFromTable('glpi_authldaps', ['is_active' => 1]);

      if (empty($ldap_methods)) {
         $default_data['error_msg'] = 'Nenhum servidor LDAP configurado.';
         return $default_data;
      }

      $method = array_shift($ldap_methods);
      
      $ds = ldap_connect($method['host'], $method['port']);
      ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION, 3);
      ldap_set_option($ds, LDAP_OPT_REFERRALS, 0);

      $pass = (new GLPIKey())->decrypt($method['rootdn_passwd']);
      $bind = @ldap_bind($ds, $method['rootdn'], $pass);

      if (!$bind) {
         $default_data['error_msg'] = 'Falha de autenticação no AD.';
         return $default_data;
      }

      $filter = "(sAMAccountName=$login)";
      $attributes = ['userAccountControl', 'lockoutTime', 'pwdLastSet', 'lastLogonTimestamp'];
      
      $sr = @ldap_search($ds, $method['basedn'], $filter, $attributes);
      
      if (!$sr) {
          $default_data['error_msg'] = 'Erro na busca LDAP.';
          return $default_data;
      }
      
      $info = ldap_get_entries($ds, $sr);

      if ($info['count'] == 0) {
         $default_data['error_msg'] = 'Usuário não encontrado no AD.';
         ldap_unbind($ds);
         return $default_data;
      }

      // Dados brutos
      $uac = $info[0]['useraccountcontrol'][0];
      $lockoutTime = isset($info[0]['lockouttime'][0]) ? $info[0]['lockouttime'][0] : 0;
      $pwdLastSet = isset($info[0]['pwdlastset'][0]) ? $info[0]['pwdlastset'][0] : 0;
      
      // Lógica de Negócio
      $data = $default_data;
      $data['error_msg'] = ''; // Limpa erro
      $data['status_class'] = 'active';
      $data['status_text'] = 'ATIVO';
      $data['icon'] = 'fa-check-circle';

      // Bit 2 = Disabled
      if ($uac & 2) {
         $data['status_class'] = 'disabled';
         $data['status_text'] = 'DESATIVADO';
         $data['icon'] = 'fa-ban';
         $data['reason'] = 'Conta desabilitada manualmente.';
      } 
      elseif ($lockoutTime > 0) {
         $data['status_class'] = 'locked';
         $data['status_text'] = 'BLOQUEADO';
         $data['icon'] = 'fa-lock';
         $data['reason'] = 'Excesso de tentativas de senha.';
      }

      // Senha
      if ($pwdLastSet == 0) {
          $data['password_expired'] = true;
      }

      // Data
      if (isset($info[0]['lastlogontimestamp'][0])) {
         $winTime = $info[0]['lastlogontimestamp'][0];
         $unixTime = ($winTime / 10000000) - 11644473600;
         $data['last_logon'] = date("d/m/Y H:i", $unixTime);
      }

      ldap_unbind($ds);
      return $data;
   }
}