function plugin_init_adstatus() {
   global $PLUGIN_HOOKS;
   $PLUGIN_HOOKS['csrf_compliant']['adstatus'] = true;
   
   // Se usar o CSS dentro do Twig, pode comentar essa linha abaixo:
   // $PLUGIN_HOOKS['add_css']['adstatus'] = "css/style.css";

   if (class_exists('PluginAdstatusUserstatus')) {
      Plugin::registerClass('PluginAdstatusUserstatus', array('addtabon' => array('User')));
   }
}
// O restante igual ao anterior...