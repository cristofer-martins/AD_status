<?php

function plugin_adstatus_install() {
   return true;
}

function plugin_adstatus_uninstall() {
   return true;
}